%% Classification on IRIS dataset, 3 classes and 4 features

%% Initialization
eps = 0.001;
maxepoch = 1000;
rng(8576)
m = 135;        % Training examples
no_o_units = 3; % output units
no_v_units = 4;
no_h_units = 9;
bias_first = zeros(no_h_units,m);
bias_sec = zeros(no_o_units,m);
w1 = randn(no_h_units,no_v_units);
w2 = randn(no_o_units,no_h_units);
y = eye(3);

load fisheriris
cvo = cvpartition(species,'k',10);

%% 10 fold Cross-validation
for i = 1:cvo.NumTestSets % 10 sets
    
    trIdx = cvo.training(i); % training index
    teIdx = cvo.test(i);     
    I = meas(trIdx,:);
    I_test = meas(teIdx,:);
    labels_tr = species(trIdx,:); 
    labels_te = species(teIdx,:);
    
    % True labels for Training
    true_lab_tr = [];
    for j = 1:size(labels_tr,1)
        if strcmp(labels_tr{j},'setosa')
            true_lab_tr =[true_lab_tr y(:,1)];
        elseif strcmp(labels_tr{j},'versicolor')
            true_lab_tr =[true_lab_tr y(:,2)];
        else
            true_lab_tr =[true_lab_tr y(:,3)];
        end
    end
    
    % True labels for Testing
    true_lab_te = [];
    for j = 1:size(labels_te,1)
        if strcmp(labels_te{j},'setosa')
            true_lab_te =[true_lab_te y(:,1)];
        elseif strcmp(labels_te{j},'versicolor')
            true_lab_te =[true_lab_te y(:,2)];
        else
            true_lab_te =[true_lab_te y(:,3)];
        end
    end
    count = 0;
    
    % Feed forward Neural network
    for epoch = 1:maxepoch
        hid_act = sigmoid((w1 * I') + bias_first); % 9x135
        out_act = softmax((w2 * hid_act) + bias_sec); % 3x135
        
        %Backpropogation
        delta_3 = out_act - true_lab_tr; % 3x135
        delta_2 = sigmoid_diff(hid_act) .* (w2' * delta_3); % 9x135
        der_first = delta_2 * I; % Gradient w.r.t w1, 9x4
        der_sec = delta_3 * hid_act'; % Gradient w.r.t w2, 3x9
        
        %weight updation
        dw1 = w1 - eps*der_first;
        dw2 = w2 - eps*der_sec;
        w1 = dw1;
        w2 = dw2;
    end
    
    % Testing Neural network
    layer1 = sigmoid(w1 * I_test');
    pred_lab_te = round(softmax(w2 * layer1));
    for j = 1:size(pred_lab_te,2)
        if true_lab_te(:,j) == pred_lab_te(:,j)
            count = count + 1;
        end
    end
    percent(i) = (count/size(I_test,1))*100;
    
end

disp('Accuracy(%) for classification task in Iris training set is:')
disp(percent)