function [ g ] = softmax( z )
% each are values bet o and 1
% sum is 1
g = [];
for i = 1:size(z,2)
    temp = z(:,i);
    g = [g exp(temp)/sum(exp(temp))];
end

end

